# Tower Blocks

Tower Blocks Game with HTML CSS JS.

#

# How to Use

Open `index.html` with your browser!

#

## Links

Demo of Game: [dori-dev.github.io/tower-blocks](https://dori-dev.github.io/tower-blocks/)

Download Code: [Click Here](https://github.com/dori-dev/tower-blocks/archive/refs/heads/master.zip)

Source: [Click Here](https://codepen.io/ste-vg/pen/ppLQNW)

My Github Account: [Click Here](https://github.com/dori-dev/)
